package com.gjg.guoaiagent.demo.invoke;

/**
 * 仅用于测试获取 API Key
 */
public interface TestApiKey {

    // 修改为你的 API Key
    String API_KEY = "sk-ffd3a68542004a0e913afce9d1b2e6bd";
}
