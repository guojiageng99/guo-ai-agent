package com.gjg.guoaiagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuoAiAgentApplicationTests {

    @Test
    void contextLoads() {
    }

}
